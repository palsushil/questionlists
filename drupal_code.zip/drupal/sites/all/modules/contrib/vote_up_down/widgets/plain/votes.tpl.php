<?php
/**
 * @file
 * votes.tpl.php
 *
 * Plain widget votes display for Vote Up/Down
 */
?>
<span id="<?php print $id; ?>" class="total-votes-plain"><span class="<?php print $class; ?> total"><?php print $unsigned_points; ?> <?php print $vote_label; ?></span></span>
